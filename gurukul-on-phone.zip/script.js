const data = {
  5: {  // Example: Class 5
    Maths: [
      {
        chapter: "Fractions",
        ncert: "https://ncert.nic.in/textbook.php?jessid=5-Maths",
        mindmap: "Fractions: numerator, denominator, types, operations, real-life use.",
        mcq: [
          "What is 1/2 of 10? (MCQ)",
          "Which fraction is greater: 1/3 or 1/2? (MCQ)"
        ]
      },
      {
        chapter: "Decimals",
        ncert: "https://ncert.nic.in/textbook.php?jessid=5-Maths",
        mindmap: "Decimals: place value, addition, subtraction, conversion from fractions.",
        mcq: [
          "Write 0.75 as fraction. (MCQ)",
          "Add 0.5 + 0.25. (MCQ)"
        ]
      }
    ],
    EVS: [
      {
        chapter: "Plants & Animals",
        ncert: "https://ncert.nic.in/textbook.php?jessid=5-EVS",
        mindmap: "Plants: parts, types; Animals: classification, habitats, adaptations.",
        mcq: [
          "Name two animals that live on land. (MCQ)",
          "Which part of plant absorbs water? (MCQ)"
        ]
      }
    ]
  }
};

// Render all content dynamically
const container = document.getElementById('content');

for (let cls in data) {
  const classHeader = document.createElement('h2');
  classHeader.innerText = `Class ${cls} (CBSE)`;
  container.appendChild(classHeader);

  for (let subject in data[cls]) {
    const card = document.createElement('div');
    card.className = 'card';
    const subjHeader = document.createElement('div');
    subjHeader.className = 'subject';
    subjHeader.innerText = `📘 ${subject}`;
    card.appendChild(subjHeader);

    data[cls][subject].forEach(ch => {
      const chapDiv = document.createElement('div');
      chapDiv.className = 'chapter';
      chapDiv.innerHTML = `
        📖 ${ch.chapter} <br>
        <a class="ncert" href="${ch.ncert}" target="_blank">NCERT Official Text</a>
        <div class="mindmap">Mindmap: ${ch.mindmap}</div>
        <div class="practice">Practice MCQs:<br>${ch.mcq.join('<br>')}</div>
      `;
      card.appendChild(chapDiv);
    });

    container.appendChild(card);
  }
}
document.addEventListener("DOMContentLoaded", function () {
  console.log("JS Loaded Successfully");
});

function openClass(num) {
  alert("Class " + num + " selected");
}
function changeLanguage() {
  let lang = document.getElementById("language").value;
  alert("Language selected: " + lang);
}
fetch("data/cbse.json")
const cbseData = {
  "Class6": {
    "Science": [
      "Food: Where Does It Come From?",
      "Components of Food"
    ]
  }
};

console.log(cbseData);
function test() {
  alert("Button works!");
}
function openPage(page) {
  window.location.href = page;
}
function changeLanguage() {
  const lang = document.getElementById("languageSelect").value;
  const elements = document.querySelectorAll("[data-en]");

  elements.forEach(el => {
    if (lang === "hi") {
      el.innerText = el.getAttribute("data-hi");
    } else {
      el.innerText = el.getAttribute("data-en");
    }
  });
}
function checkAnswer(btn) {
  const mcqDiv = btn.parentElement;         // Get the MCQ container
  const correctAnswer = mcqDiv.getAttribute("data-answer");
  const selected = mcqDiv.querySelector("input[type='radio']:checked");

  const resultP = mcqDiv.querySelector(".result");

  if (!selected) {
    resultP.innerText = "Please select an option!";
    resultP.style.color = "orange";
    return;
  }

  if (selected.value === correctAnswer) {
    resultP.innerText = "✅ Correct!";
    resultP.style.color = "green";
  } else {
    resultP.innerText = `❌ Wrong! Correct answer: ${correctAnswer}`;
    resultP.style.color = "red";
  }
}